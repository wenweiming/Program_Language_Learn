#ifndef TapeModuleH
#define TapeModuleH

namespace SAMSCalculator
{
	void Tape(const char theOperator,const float theOperand = 0);
};

#endif
