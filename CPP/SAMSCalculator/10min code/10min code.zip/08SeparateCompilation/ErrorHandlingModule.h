#ifndef ErrorHandlingModuleH
#define ErrorHandlingModuleH

namespace SAMSErrorHandling
{
   void Initialize(void);
   int HandleNotANumberError(void); // Returns the error code
}

#endif
