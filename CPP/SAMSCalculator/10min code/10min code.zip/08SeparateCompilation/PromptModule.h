#ifndef PromptModuleH
#define PromptModuleH

namespace SAMSPrompt
{
	void PauseForUserAcknowledgement(void);
}

#endif
