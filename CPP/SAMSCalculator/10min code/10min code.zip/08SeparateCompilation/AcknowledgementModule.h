#ifndef AcknowledgementModuleH
#define AcknowledgementModuleH

namespace SAMSAcknowledgement
{
	void PauseForUserAcknowledgement(void);
}

#endif
