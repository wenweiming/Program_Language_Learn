#include "TapeModule.h"

namespace SAMSCalculator
{
	aTape::aTape(void)
   {
   };

   aTape::~aTape(void)
   {
   };
};
