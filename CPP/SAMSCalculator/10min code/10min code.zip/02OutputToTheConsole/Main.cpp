#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
	// Without the "using" statement, this would be std::cout
	cout << "Hi there!" << endl; // "endl"  = next line
	return 0;
}


