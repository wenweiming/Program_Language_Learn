#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
	cout << ((6/2)+3) << endl;

   // Note: You must type something before the Enter key
   char StopCharacter;
   cout << endl << "Press a key and \"Enter\": ";
   cin >> StopCharacter;

	return 0;
}

