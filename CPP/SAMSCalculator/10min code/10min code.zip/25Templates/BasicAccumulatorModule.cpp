#include "BasicAccumulatorModule.h"

