#include <iostream>
#include <exception>

#include "RequestModule.h"

namespace SAMSCalculator
{
};
